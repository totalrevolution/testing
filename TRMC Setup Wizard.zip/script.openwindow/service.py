﻿import os
import requests
import threading
import urllib
import xbmc
import xbmcaddon
import xbmcgui

ADDON    = xbmcaddon.Addon(id='script.openwindow')
DIALOG   = xbmcgui.Dialog()
addons   = xbmc.translatePath('special://home/addons')
packages = os.path.join(addons,'packages')
repo_zip = os.path.join(packages,'repository.spartacus.zip')
#-----------------------------------------------------------------------------
def Grab_Log():
    log_path    = xbmc.translatePath('special://logpath/')
    logfilepath = os.listdir(log_path)
    finalfile   = 0
    for item in logfilepath:
        cont = False
        if item.endswith('.log') and not item.endswith('.old.log'):
            mylog        = os.path.join(log_path,item)
            cont = True
        if cont:
            lastmodified = os.path.getmtime(mylog)
            if lastmodified>finalfile:
                finalfile = lastmodified
                logfile   = mylog
    
    logtext_final = ''
    openfile = open(logfile, 'r')
    logtext  = openfile.read()
    openfile.close()
    return logtext
#-----------------------------------------------------------------------------
def Download_Repo():
    urllib.urlretrieve('https://github.com/totalrevolution/testing/blob/master/zips/repository.spartacus/repository.spartacus.zip?raw=true', repo_zip)
#-----------------------------------------------------------------------------
def WiFi_Check():
    success = False
    while not success:
        if xbmc.getCondVisibility("System.HasAddon(repository.spartacus)"):
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.executebuiltin('UpdateAddonRepos')
            success = True
        else:
            try:
                query = '{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"repository.spartacus", "enabled":true}, "id":1}'
                response = xbmc.executeJSONRPC(query)
                xbmc.log('JSON RESPONSE: %s'%response,2)
                r    = requests.get('http://google.com')
                code = r.status_code
                Main_Run()
            except:
                DIALOG.ok(ADDON.getLocalizedString(30000),ADDON.getLocalizedString(30001))

                content = Grab_Log()
                if xbmc.getCondVisibility('System.Platform.Android'):
                    xbmc.executebuiltin('StartAndroidActivity(,android.settings.WIFI_SETTINGS)')
                
                elif xbmc.getCondVisibility('System.Platform.OSX'):
                    os.system('open /System/Library/PreferencePanes/Network.prefPane/')

                elif xbmc.getCondVisibility('System.Platform.Windows'):
                    os.system('ncpa.cpl')

                elif 'Running on OpenELEC' in content or 'Running on LibreELEC' in content:

                    if xbmc.getCondVisibility("System.HasAddon(service.openelec.settings)") or xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings)"):
                        if xbmc.getCondVisibility("System.HasAddon(service.openelec.settings)"): 
                            xbmcaddon.Addon(id='service.openelec.settings').getAddonInfo('name')
                            xbmc.executebuiltin('RunAddon(service.openelec.settings)')
                        elif xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings)"):
                            xbmcaddon.Addon(id='service.libreelec.settings').getAddonInfo('name')
                            xbmc.executebuiltin('RunAddon(service.libreelec.settings)')
                        xbmc.sleep(1500)
                        xbmc.executebuiltin('Control.SetFocus(1000,2)')
                        xbmc.sleep(500)
                        xbmc.executebuiltin('Control.SetFocus(1200,0)')

                elif xbmc.getCondVisibility('System.Platform.Linux'):
                    os.system('nm-connection-editor')

                DIALOG.ok(ADDON.getLocalizedString(30002),ADDON.getLocalizedString(30003))
#-----------------------------------------------------------------------------
def Main_Run():
    if not xbmc.getCondVisibility('System.HasAddon(repository.spartacus)'):
        import zipfile
        download_thread = threading.Thread(target=Download_Repo)
        download_thread.start()
        download_alive = download_thread.isAlive()
        while download_alive:
            xbmc.sleep(1000)
            download_alive = download_thread.isAlive()
        zin = zipfile.ZipFile(repo_zip,  'r')
        zin.extractall(addons)
        xbmc.sleep(2000)
        xbmc.executebuiltin('UpdateLocalAddons')
        addon_ok = False
        counter  = 0
            
        while not addon_ok:
            xbmc.sleep(1000)
            counter += 1
            query = '{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"repository.spartacus", "enabled":true}, "id":1}'
            response = xbmc.executeJSONRPC(query)
            addon_ok = xbmc.getCondVisibility("System.HasAddon(repository.spartacus)")
            if not addon_ok:
                xbmc.log('Repo not installed, sleeping %ss'%counter,2)
        query = '{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"repository.spartacus", "enabled":true}, "id":1}'
        response = xbmc.executeJSONRPC(query)
        xbmc.log('JSON RESPONSE: %s'%response,2)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')

if __name__ == '__main__':
    WiFi_Check()